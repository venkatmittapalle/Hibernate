package com.venki;

import java.util.*;
import java.lang.Math;

public class a4q1 {
	
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please input 3 integers: ");
        int x = input.nextInt();
        int y = input.nextInt();
        int z = input.nextInt();
        int max = Math.max(Math.max(x,y),z);
        System.out.println("The max of ( "+x+","+y+","+z+" ) is : " + max);
    	}
}
